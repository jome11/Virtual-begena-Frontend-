import 'package:flutter/material.dart';
import '../../core/theme/app_color_scheme.dart';
import '../../core/theme/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/services/progress_service.dart';
import '../../shared/widgets/panel_card.dart';
import '../../shared/widgets/mode_app_bar.dart';

class TrainingPlanScreen extends StatefulWidget {
  const TrainingPlanScreen({super.key});

  @override
  State<TrainingPlanScreen> createState() => _TrainingPlanScreenState();
}

class _TrainingPlanScreenState extends State<TrainingPlanScreen> {
  Future<Map<String, dynamic>>? _future;

  @override
  void initState() {
    super.initState();
    _future = ProgressService.getRecommendations();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Language>(
      valueListenable: languageNotifier,
      builder: (context, lang, _) {
        return Scaffold(
          backgroundColor: context.colors.background,
          appBar: ModeAppBar(
            modeLabel: AppStrings.get('mode_training_plan').toUpperCase(),
            modeColor: AppColors.modeTrainingPlan,
          ),
          body: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 600),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    PanelCard(
                      child: Column(children: [
                        const SizedBox(height: 8),
                        const Icon(Icons.music_note,
                            color: AppColors.modeTuning, size: 32),
                        const SizedBox(height: 10),
                        Text(
                          AppStrings.get('mode_training_plan'),
                          style: TextStyle(
                            color: context.colors.textPrimary,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          AppStrings.get('dashboard_subtitle'),
                          style: TextStyle(
                              color:
                                  context.colors.textSecondary.withValues(alpha: 0.8)),
                        ),
                        const SizedBox(height: 8),
                      ]),
                    ),
                    const SizedBox(height: 16),
                    FutureBuilder<Map<String, dynamic>>(
                      future: _future,
                      builder: (context, snapshot) {
                        final data = snapshot.data;
                        final String message;
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          message = 'Analyzing your progress...';
                        } else if (snapshot.hasError || data == null) {
                          message = AppStrings.get('coming_soon');
                        } else {
                          message = data['recommendations']?.toString() ??
                              AppStrings.get('coming_soon');
                        }

                        return PanelCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                const Text('📋 ', style: TextStyle(fontSize: 14)),
                                Text(
                                  AppStrings.get('mode_training_plan_sub')
                                      .toUpperCase(),
                                  style: const TextStyle(
                                    color: AppColors.success,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                              ]),
                              const SizedBox(height: 10),
                              Text(
                                message,
                                style: TextStyle(
                                    color: context.colors.textSecondary
                                        .withValues(alpha: 0.9)),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                    OutlinedButton.icon(
                      onPressed: () => setState(
                          () => _future = ProgressService.getRecommendations()),
                      icon: const Icon(Icons.refresh, size: 16),
                      label: Text(AppStrings.get('restart')),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

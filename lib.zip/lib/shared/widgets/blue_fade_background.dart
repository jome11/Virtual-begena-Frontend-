import 'package:flutter/material.dart';

class BlueFadeBackground extends StatelessWidget {
  final Widget child;
  const BlueFadeBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors = dark
        ? const [Color(0xFF1C1710), Color(0xFF14110B), Color(0xFF0C0B08)]
        : const [Color(0xFFE9DDB8), Color(0xFFF2ECDC), Color(0xFFF8F4EA)];
    return SizedBox.expand(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: const [0.0, 0.45, 1.0],
            colors: colors,
          ),
        ),
        child: child,
      ),
    );
  }
}

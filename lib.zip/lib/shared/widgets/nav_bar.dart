import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/brand_palette.dart';
import '../../core/constants/app_strings.dart';
import 'theme_toggle_button.dart';

class NavBar extends StatelessWidget implements PreferredSizeWidget {
  const NavBar({super.key});

  @override
  Size get preferredSize => const Size.fromHeight(80);

  @override
  Widget build(BuildContext context) {
    final brand = context.brand;
    return ValueListenableBuilder<Language>(
      valueListenable: languageNotifier,
      builder: (context, lang, _) {
        final isDesktop = MediaQuery.of(context).size.width > 900;
        return Container(
          color: brand.background,
          padding: EdgeInsets.symmetric(horizontal: isDesktop ? 32 : 16, vertical: 20),
          child: Row(
            children: [
              Text(
                AppStrings.get('app_title'),
                style: TextStyle(
                  color: brand.ink,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              if (isDesktop) ...[
                _NavLink(label: AppStrings.get('home'), onTap: () => context.go('/home')),
                _NavLink(
                  label: lang == Language.en ? 'How to use' : 'እንዴት መጠቀም',
                  onTap: () => context.go('/how-to-use'),
                ),
                _NavLink(label: AppStrings.get('shop'), onTap: () => context.go('/shop')),
                _NavLink(label: AppStrings.get('about'), onTap: () => context.go('/about')),
                _NavLink(label: AppStrings.get('contact'), onTap: () => context.go('/contact')),
                const SizedBox(width: 8),
              ] else ...[
                PopupMenuButton<String>(
                  icon: Icon(Icons.menu_rounded, color: brand.ink),
                  onSelected: (route) => context.go(route),
                  itemBuilder: (context) => [
                    PopupMenuItem(value: '/home', child: Text(AppStrings.get('home'))),
                    PopupMenuItem(value: '/how-to-use', child: Text(lang == Language.en ? 'How to use' : 'እንዴት መጠቀም')),
                    PopupMenuItem(value: '/shop', child: Text(AppStrings.get('shop'))),
                    PopupMenuItem(value: '/about', child: Text(AppStrings.get('about'))),
                    PopupMenuItem(value: '/contact', child: Text(AppStrings.get('contact'))),
                  ],
                ),
                const SizedBox(width: 4),
              ],
              const _LanguageToggle(),
              const SizedBox(width: 8),
              const ThemeToggleButton(),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () => context.go('/login'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: brand.amber,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: EdgeInsets.symmetric(horizontal: isDesktop ? 22 : 14, vertical: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                ),
                child: Text(
                  AppStrings.get('get_started'),
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _LanguageToggle extends StatelessWidget {
  const _LanguageToggle();

  @override
  Widget build(BuildContext context) {
    final brand = context.brand;
    return ValueListenableBuilder<Language>(
      valueListenable: languageNotifier,
      builder: (context, lang, _) {
        return TextButton(
          onPressed: () {
            languageNotifier.value = lang == Language.en ? Language.am : Language.en;
          },
          child: Text(
            lang == Language.en ? 'አማ' : 'EN',
            style: TextStyle(
              color: brand.amber,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        );
      },
    );
  }
}

class _NavLink extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _NavLink({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final brand = context.brand;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: TextButton(
        onPressed: onTap,
        child: Text(
          label,
          style: TextStyle(
            color: brand.ink.withValues(alpha: 0.7),
            fontSize: 13.5,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
